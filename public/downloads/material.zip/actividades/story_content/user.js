function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5bH5BxQ4kYJ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

