function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5rc0Jp3BMQg":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

